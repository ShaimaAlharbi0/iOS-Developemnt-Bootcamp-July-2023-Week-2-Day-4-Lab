//
//  hobbyApp.swift
//  hobby
//
//  Created by Shaima Alharbi on 16/01/1445 AH.
//

import SwiftUI

@main
struct hobbyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
