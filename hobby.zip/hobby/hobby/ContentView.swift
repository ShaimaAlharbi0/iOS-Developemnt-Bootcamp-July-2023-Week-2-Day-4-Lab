//
//  ContentView.swift
//  hobby
//
//  Created by Shaima Alharbi on 16/01/1445 AH.
//

import SwiftUI

import SwiftUI

enum CardCategory{
    case Game
    case music
    case Dance
}

struct CardData: Identifiable {
    let id: UUID = UUID()
    let title: String
    let subtitle: String
    let price: Int
    var category: CardCategory
    let imageURL: URL? // Optional<URL>
}
func makeCardData()->Array<CardData>{
    return
musicList.map { music in
CardData(
title: music,
subtitle: " ",
price: 10,
category: .music,
imageURL:URL(string:"https://source.unsplash.com/200x200/?\(music)")
    
       )
        
    } +

  //  Array(
  //      repeating:
  //          CardData(
  //              title: "Music",
  //              subtitle: " ",
   //             price: 10,
   //             category: .music,
   //             imageURL: URL(string:"https://source.unsplash.com/200x200/?music")
   //         ),
    //    count:10
  //  ) +
        
        Array(
            repeating:
                CardData(
                    title: "Game",
                    subtitle: " ",
                    price: 10,
                    category: .Game,
                    imageURL:URL(string:  "https://source.unsplash.com/200x200/?Game")
                ),
            count: 10
            ) +
        
    Array(
     repeating:
         CardData(
              title: "Dance",
              subtitle: " ",
              price: 10,
              category: .Dance,
              imageURL:URL(string: "https://source.unsplash.com/200x200/?Dance")
                    ),
                count: 10
                )
}
struct CardView: View {
    let data: CardData
    var body: some View {
        GeometryReader { geometryProxy in
            ZStack {
                AsyncImage(url: data.imageURL) { result in
                    if let image = result.image {
                        image
                            .resizable()
                            .scaledToFill()
                    } else {
//                        Rectangle()
//                            .fill(Color.black.opacity(0.1))
                        ProgressView()
                    }
                }
                .frame(
                    width: geometryProxy.size.width,
                    height: geometryProxy.size.height
            )
                VStack {
                    Spacer()
                    Text(data.title)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    Text(data.subtitle)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                .padding(8)
                .foregroundColor(.white)
                .background(
                    Gradient(
                        colors: [
                            Color.clear,
                            Color.clear,
                            Color.clear,
                            Color.black
                        ]
                    )
                )
            }
            .cornerRadius(12)
            .frame(
                width: geometryProxy.size.width,
                height: geometryProxy.size.height
            )
        }
    }
}
struct ContentView: View {
    let categories: Array<String> = [
        "Discover",
        "⚽️ Sports",
        "🎷 Music",
        "🎭 Shows"
    ]
    
    let cards: Array<CardData> = makeCardData()
    @State var filteredCards:Array<CardData> = []
    @State var searchedText: String = ""
    
    
    func prepareDataForUser(){
        filteredCards = cards
    }
    
    var musicCardData: Array<CardData> { cards.filter{
        cardsData in cardsData.category == .music
    }}
   

    var body: some View {
        NavigationStack {
            VStack {
                // MARK: Title
                Text("")
                .navigationTitle("hobby")
                .background {
                  }
                // MARK: Search Box
                HStack {
                    Image(systemName: "swift")
                    TextField("Search", text: $searchedText)
                        .frame(height: 40)
                }
                .padding(.vertical, 8)
                .padding(.horizontal, 4)
                .background(Color.gray.opacity(0.3))
                .cornerRadius(12)
                // MARK: Categories
                ScrollView(.horizontal) {
                    HStack {
                        ForEach(categories, id: \.self) { category in
                            Button(
                                action: {
                                    switch category {
                                    case "🎮 Game":
                                        filteredCards=cards.filter({card
                                            in card.category == .Game})
                                    case "🎷 Music":
                                        filteredCards = musicCardData
                                    case "💃 Dance":
                                        filteredCards = cards.filter({
                                            card in card.category == .Dance})
                                    default:
                                        filteredCards = cards
                                        
                                    }
                                },
                                
                                label: {
                                    Text(category)
                                    
                                        .padding(.vertical, 8)
                                        .padding(.horizontal, 16)
                                        .background(Color.gray.opacity(0.3))
                                        .foregroundColor(Color.black)
                                        .cornerRadius(12)
                                })
                            
                        }
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
                ScrollView {
                    // Headline Card
                    CardView(
                        data: CardData(
                            title: "NO Pelicans @ BRK Nets",
                            subtitle: "Wed 10/19 • 7:30 PM • $33",
                            price: 0,
                            category: .Game,
                            imageURL: URL(string: "https://source.unsplash.com/500x300/?live")
                        )
                    )
                    .frame(height: 200)
                    .clipped()
                    // MARK: Popular Cards
                    HStack {
                        Text("Popular")
                        Spacer()
                     
                        NavigationLink(
                            destination: {
                                Text("Hello, am second view")
                            },
                            label: {
                                Text("See All >")
                            }
                        )
                    }
                    ScrollView(.horizontal) {
                        HStack {
                            ForEach(filteredCards){
                                card in
                                if card.category == .Dance {
                                    
                                    CardView(data: card)
                                        .frame(width: 300, height: 150)
                                }
                            }
                        }
                    }
                    HStack {
                        Text("Game")
                        Spacer()
                        NavigationLink(
                            destination: {
                                Text("Hello, am second view")
                            },
                            label: {
                                Text("See All >")
                            }
                        )
                    }
                    ScrollView(.horizontal) {
                        HStack {
                            ForEach(filteredCards){
                                card in
                                if card.category == .Game {
                                    
                                    CardView(data: card)
                                        .frame(width: 300, height: 150)
                                }
                            }
                        }
                    }
                    HStack {
                        Text("Music")
                        Spacer()
                       
                        NavigationLink(
                            destination: {
                                List(musicCardData) { cards in
                                    NavigationLink(
                                        destination: {
                                            Text(cards.title)
                                        },
                                        label: {
                                        Text(cards.title)
                                    }
                                        )
                                        
                                        }
                                        
                                        },
                            
                            label: {
                                Text("See All >")
                            }
                        )
                    }
                    ScrollView(.horizontal) {
                        HStack {
                            ForEach(filteredCards){
                                card in
                                if card.category == .music {
                                    
                                    CardView(data: card)
                                        .frame(width: 300, height: 150)
                                }
                            }
                        }
                    }
                    HStack {
                        Text("Dance")
                        Spacer()
                        NavigationLink(
                            destination: {
                                Text("Hello, am second view")
                            },
                            label: {
                                Text("See All >")
                            }
                        )
                    }
                    ScrollView(.horizontal) {
                        HStack {
                            ForEach(filteredCards){
                                card in
                                if card.category == .Dance {
                                    
                                    CardView(data: card)
                                        .frame(width: 300, height: 150)
                                }
                            }
                        }
                    }
                }
            }
        }.onAppear{
            PrepareDataForUser()
        }.onChange(of: searchedText){ value in
            filteredCards(value)
            
        }
     
    }
    
    func PrepareDataForUser(){
        filteredCards = cards
    }
    
    func filteredCards(_ value :  String){
        if value.isEmpty {
            filteredCards = cards
        }else {
            let lowercasedValue = value.lowercased()
            filteredCards = cards.filter({ card in
                return card.title.lowercased()
                    .contains(lowercasedValue)
            })
        }
        
    }
    
}
    

struct ProfileView: View {
    let arrayOfNumber: Array<String> = Array (0...9).map {
        number in
        number.description
    }
    @State var mobileNumber: String = ""
    @State var showAlert: Bool = false
    @State var alertMessage: String = ""
    
    func validateMobileNumber(_ value: String) {
        if value.isEmpty {
            showAlert = true
            alertMessage = "kindly enter a mobile number"
        } else if value.count > 10 {
            showAlert = true
            alertMessage = "kindly enter a less than 10 digits"
            
        } else {
            var isNumber = true
            value.forEach { char in
                if !char.isNumber {
                    isNumber = false
                    return
                }
            }
            if !isNumber{
                showAlert = true
                alertMessage = "kindly enter a valid mobile number"
                // kindly enter a valid mobile number
                
            }
        }
    }
    
    var body: some View{
        Form {
            Section{
                List(arrayOfNumber, id:\.self) {number
                    in
                    NavigationLink(
                        destination:  {
                            Text(number)
                                .foregroundColor(.orange)
                        },
                        label: {
                            Text(number)
                        }
                    )
                }
                // Alert (عرفناه)
                .alert(isPresented: $showAlert) {
                    Alert(title: Text(alertMessage))
                    
                }
            }
        }
    }
    
        struct ContentView_Previews: PreviewProvider {
                    static var previews: some View {
                        NavigationStack{
                            TabView {
                                ContentView()
                                    .tabItem {
                                        Label("Discovery", systemImage:"tray.and.arrow.down.fill"
                                        )}
                                ProfileView()
                                    .tabItem {
                                        Label("Profile", systemImage: "person.crop.circle")
                                    }
                            }
                        }
                        
             
        }
    }
}

                    
                    
                    
let musicList: Array<String> = """
Breakdancing
Competitive dancing
Cheerleading
Dancesport
Dragon dance and Lion dance
Figure skating
Gymnastics
High kick
Parkour
Pole sports
Stunt
Trampolining
Color guard
"""
.components(separatedBy: "\n")
                    
     
